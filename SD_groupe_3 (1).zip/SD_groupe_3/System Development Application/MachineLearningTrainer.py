import random
import math
from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn import svm
from time import time
import pickle
import copy
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score
from sklearn.metrics import roc_auc_score

#all of the libraries need for training,testing,validating,storing the machine learning model
from pymongo import MongoClient
def buildModel(file_sent):
    start_time = time()

    column_names = ['end_tidal_co2', 'feed_vol', 'feed_vol_adm', 'fio2', 'fio2_ratio', 'insp_time', 'oxygen_flow_rate', 'peep', 'pip', 'resp_rate', 'sip', 'tidal_vol', 'tidal_vol_actual', 'tidal_vol_kg', 'tidal_vol_spon', 'bmi']

    print("Hello world")

    filename=file_sent

    if ".csv" not in filename:
        print("Error File name is not valid, it does not contain the extension .csv")

    try:
        dataFrame = pd.read_csv(filename)
    except:
        print("Failed to upload the CSV file")
    else:
        dataFrame_Original=dataFrame.copy()


        column_to_drop=["encounterId","referral"] #getting rid of encounterID, since it is relevant to training
        for column in column_to_drop:
            dataFrame.drop(column,axis=1,inplace=True)
        #we also get rid of referral, so we can use this data as X
            
            
        dataFrame.fillna(0, inplace=True) #filling empty cells with zeros, e.g. if there is a cell with NaN value, it will be replace with zero
        print(dataFrame)
        X=dataFrame
        y=dataFrame_Original["referral"] #retreiving the labels/target column only


        X_train, X_test_validation, y_train, y_test_validation = train_test_split(X, y, test_size=0.3, random_state=42)
        X_test, X_validation, y_test, y_validation = train_test_split(X_test_validation, y_test_validation, test_size=0.3, random_state=42)

        #70% for the training dataset, 30% for the testing dataset
        weight_zero=len(dataFrame_Original["referral"])/(dataFrame_Original["referral"]==0).sum()
        weight_one=len(dataFrame_Original["referral"])/(dataFrame_Original["referral"]==1).sum()


        class_weights_list={0:weight_zero,1:weight_one}
        print(class_weights_list)



    N=2 #size of the hyperparameters, for rbf, we have C, and gamma
    fold_number=5

    class individual:
        def __init__(self) -> None:
            self.gene=[0]*N
            self.fitness=0
        def calculate_fitness(self):

            # support_vector_classifer_model = svm.SVC(kernel='rbf', C=self.gene[0] ,gamma=self.gene[1])
            pipeline = make_pipeline(
            StandardScaler(),
            svm.SVC(kernel='rbf', C=self.gene[0] ,gamma=self.gene[1], class_weight=class_weights_list)
            )
            
            # return accuracy_score(y_validation,pipeline.predict(X_validation))
            # return roc_auc_score(y_validation,pipeline.predict_proba(X_validation)[:, 1])
            
            return cross_val_score(pipeline.fit(X_train,y_train),X_validation,y_validation,cv=fold_number).mean()


                
    def generate_random_C():
        return random.uniform(0.001,70)

    def generate_random_gamma():
        return random.uniform(0.0001,7)

    # def generate_random_degree():
    #     return random.randint(1,10)


    current_solution_gene=[generate_random_C(),generate_random_gamma()]

    current_solution=individual()
    current_solution.gene=current_solution_gene.copy()

    #temperature
    T=50
    i=1 #number of steps allowed at a certain temperature
    while (T!=1):
        for one_iteration in range(i):
            next_solution_gene=[generate_random_C(),generate_random_gamma()]
            next_solution=individual()
            next_solution.gene=current_solution_gene.copy()

        #calculate the difference in energy
            
            next_solution_fitness_value=next_solution.calculate_fitness()
            change_in_energy=next_solution_fitness_value-current_solution.calculate_fitness()

            if change_in_energy > 0:
                current_solution=next_solution.copy()
            elif math.exp((change_in_energy)/T) > random.random(): #accept a bad solution if only it passes this test
                current_solution=copy.deepcopy(next_solution)
                #note that if T is high, it is more likely to accept bad solutions initially, as T decreases
                #it will tend to accept good solutions more
        i=1
        T-=1
        print("Temp now is ",T)
    print("Best solution is ",current_solution.gene,"Accuracy is ",current_solution.calculate_fitness())


    end_time=time()
    print("End time is ",end_time-start_time)

    #creating a pipeline object, ,scaling it making std=1, mean =0 , by using standardscaler transformer
    #then training it using rbf kernel/gaussian kernel , then making a prediction and finally
    #getting the overally accuracy by comparing the two [predicted vs actual]
    pipeline = make_pipeline(
            StandardScaler(),
            svm.SVC(kernel='rbf', C=current_solution.gene[0] ,gamma=current_solution.gene[1],probability=True,class_weight=class_weights_list)
            )

    # print("Now testing dataset",accuracy_score(y_test,pipeline.fit(X_train,y_train).predict(X_test)))
    pipeline.fit(X_train,y_train)


    y_prediction=pipeline.decision_function(X_test)

    auc = round(roc_auc_score(y_test,y_prediction),4)

    overall_accuracy=accuracy_score(y_test,pipeline.predict(X_test))*100
    print("AUC value is",auc)
    print("Overall accuracey of the model is ",overall_accuracy)


    client = MongoClient("mongodb+srv://ccugroupproject:groupproject123ABC@ccuproject.nckjj78.mongodb.net/")
    db = client['CCU_Dashboard']  # Access the database
    collection = db['Machine_Learning_Model'] 

    class Trained_Model:
        def __init__(self,model,accuracy_per,auc,model_id="") -> None:
            self.model_id=collection.count_documents({})+1
            self.model=model
            self.accuracy_per=round(accuracy_per, 1)
            self.auc=auc
        
        def setModel(self,model):
            self.mode=model
        def getModel(self):
            return self.model
        def getAccuracy(self):
            return self.accuracy_per
        def getModel_ID(self):
            return self.model_id
        def getAUC(self):
            return self.auc

    model_value=pickle.dumps(pipeline)
    print("model value is ",model_value)
    Best_Model=Trained_Model(model_value,overall_accuracy,auc)
        # with open(support_vector_classifer_model_file, 'wb') as file:  
        #     pickle.dump(support_vector_classifer_model_file, file)




    collection.insert_one({
                            'ModelId': Best_Model.getModel_ID(),
                            'Model': Best_Model.getModel(),
                            'accuracy':Best_Model.getAccuracy(),
                            'AUC':Best_Model.getAUC()
                        })
