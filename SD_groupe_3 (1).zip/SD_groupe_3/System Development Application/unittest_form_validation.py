import unittest
from ValidationInput import *

class TestValidation(unittest.TestCase):
  def test_validate_name(self):
        self.assertEqual(validate_firstname_and_lastname("Shen"), True,'First / Last Name starts with uppercase and there is no any character other than the following [A-Z], size of name should be atleast 3 characters and max 15 characters')
        self.assertEqual(validate_firstname_and_lastname("shen"), False,'First / Last Name does not start with uppercase, it should be rejected')
        self.assertEqual(validate_firstname_and_lastname("Shen2323"), False,'First / Last Name does contain numeric characters, it should be rejected')
        self.assertEqual(validate_firstname_and_lastname(""), False,'First / Last Name is empty, it should be rejected')
        self.assertEqual(validate_firstname_and_lastname("Abe p"), False,'First / Last Name contains spaces, it should be rejected')

        #############################################################################################################################
        self.assertEqual(validate_firstname_and_lastname("Ab"), False,'First / Last Name is less than 3 characters, it should be rejected')
        self.assertEqual(validate_firstname_and_lastname("Abbbbbbbbbbbbbbbbbbb"), False,'First / Last Name is more than 15 characters, it should be rejected')
    
  def test_validate_phone(self):
        self.assertEqual(validate_phone("123456789123"), True,'the phone number length is 12, it must be accepted because Phone number must be exactly 12 numeric characters')
        self.assertEqual(validate_phone("1234567891237"), False,'the phone number length is 13, it must be rejected because Phone number must be exactly 12 numeric characters')
        self.assertEqual(validate_phone(""), False,'the phone number length is 0 // empty string, it must be rejected because Phone number must be exactly 12 numeric characters')
        self.assertEqual(validate_phone("12345678912A"), False,'the phone number contains a single character [alphabet], it must be rejected because phone number must contain only numbers')

  def test_validate_password(self):
        self.assertEqual(validate_password("AB_XE456789"), True,'the password length is 10, it must be accepted because the password should be at least 10 and max 20 characters')
        self.assertEqual(validate_password("AB_XE4567"), False,'the password length is 9, it must be rejected because the password should be at least 10 and max 20 characters')
        self.assertEqual(validate_password("AB_XE456789AB_XE4567"), True,'the password length is 20, it must be accepted because the password length is 20, and it did not go beyond 20 characters')
        self.assertEqual(validate_password("AB_XE456789AB_XE4567XX"), False,'the password length is 22, it must be rejected because the password length is 22, and it should not go beyond 20 characters')
        self.assertEqual(validate_password(""), False,'the password length is 0 // empty string, it must be rejected because Password must be atleast 10  characters')


#[A-Za-z0-9\_\-]{4,15}@(gmail|yahoo|outlook)\.com$
  def test_validate_email(self):
       self.assertEqual(validate_email("yahia_b-xop@gmail.com"),True,"yahia_b-xop@gmail.com is a valid email account")
       self.assertEqual(validate_email("isl0@yahoo.com"),True,"isl0@yahoo.com is a valid email account, the first part before @ is at least 4 characters")
       self.assertEqual(validate_email("isl-@outlook.com"),True,"isl-@outlook.com is a valid email account, the first part before @ is at least 4 characters and it contains valid special characters [_,-]")
       self.assertEqual(validate_email("yahia_b-xop@example.com"),False,"yahia_b-xop@example.com is a valid email account, it is not valid because last part should be [gmail/yahoo/outlook]")
       self.assertEqual(validate_email(""),False,"empty email should not be accepted")
       self.assertEqual(validate_email("yahia@@gmail.com"),False,"yahia@@gmail.com  should not be accepted, because it contains @@ twice")
       self.assertEqual(validate_email("yahia@gmail.cEm"),False,"yahia@gmail.cEm  should not be accepted, because it contains cEm instead of com")
       self.assertEqual(validate_email("yahia@gmailcom"),False,"yahia@gmail.cEm  should not be accepted, because it is missing a dot (.)")
       ### 2 down range
  def test_validate_username(self):
       #[A-Za-z0-9]{3,14}
       self.assertEqual(validate_username("Ab3"),True,"Username can contain Alphabet and numeric characters only, and it must be min 3 characters at least and max 14 characters")
       self.assertEqual(validate_username(""),False,"empty username should not be accepted")
       self.assertEqual(validate_username("Abe2@"),False,"Abe2@ username should not be accepted,because it has @ [special characters are not allowed]")
       ##
       self.assertEqual(validate_username("Abe 2"),False,"Abe 2 should not be accepted because there is a space in between")
       self.assertEqual(validate_username("A2"),False,"A2 should not be accepted because this username has 2 character, it must have at least 3 characters")
       self.assertEqual(validate_username("Abe23232131223"),True,"That long string is 14 characters long it should be accepted as username, since max length for username is 14 characters")
       self.assertEqual(validate_username("Abe23232131223333"),False,"That long username is beyond 14 characters, it is 17 characters long, thus it should not be accepted ")
if __name__ == '__main__':
    unittest.main()