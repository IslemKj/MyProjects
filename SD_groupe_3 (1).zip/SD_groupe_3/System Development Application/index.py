from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from pymongo import MongoClient
from passlib.hash import sha256_crypt
from functools import wraps
import uuid
import random
import csv
import pandas as pd
import pickle
import numpy as np
from email.message import EmailMessage
import smtplib
import ssl
from time import time
import MachineLearningTrainer
import pymongo
from ValidationInput import *

class UserList:
    def __init__(self):
        self.user_list=[]
    def append_to_user_list(self,object):
        self.user_list.append(object)

UserList_Object=UserList()
class User:
    def __init__(self) -> None:
        self.email=""
    def setEmail(self,email):
        self.email=email
    def getEmail(self):
        return self.email

Current_User=User()


app = Flask(__name__)
app.secret_key = 'This is my Secret Key'

# MongoDB Atlas connection
client = MongoClient("mongodb+srv://ccugroupproject:groupproject123ABC@ccuproject.nckjj78.mongodb.net/")
db = client['CCU_Dashboard']  # Access the database
collection = db['user']  # Access the collection

if collection.count_documents({}) == 0:
    collection.insert_one({"_id": "user_id", "seq": 0})

@app.route('/')
def index():
    return render_template("register.html")




#code that takes us to sign when when we are not and we are trying to access some data for guest
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:            
            print("You need to login first")
            #return redirect(url_for('login', error='You need to login first'))
            return render_template('logIn.html', error='You need to login first')    
    return wrap

#code that takes us to sign when when we are not and we are trying to access some data for admin
def admin_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if ('logged_in' in session) and (session['role'] == 'Admin'):
            return f(*args, **kwargs)
        else:            
            print("You need to login first as admin user")
            #return redirect(url_for('login', error='You need to login first as admin user'))
            return render_template('logIn.html', error='You need to login first as admin user')    
    return wrap

#code that takes us to sign when when we are not and we are trying to access some data for standard
def standard_user_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if ('logged_in' in session) and (session['role'] == 'Standard'):
            return f(*args, **kwargs)
        else:            
            print("You need to login first as standard user")
            #return redirect(url_for('login', error='You need to login first as standard user'))
            return render_template('logIn.html', error='You need to login first as standard user')    
    return wrap


@app.route('/about')
@login_required
def about():
    user = Current_User
    return render_template("about.html", user = user)

@app.route('/analyse')
@login_required
def analyse():
    return render_template("analyse.html")

@app.route('/view')
@login_required
def view():
    return render_template("view.html")

@app.route('/upload')
@login_required
def upload():
    return render_template("upload.html")

@app.route('/machine_learning', methods=['POST', 'GET']) #upload CSV file here
@login_required
@admin_required
def machine_learning():
    if request.method=='POST':
            seconds=time()
            print("This is Post request")
            print("Data received for ML is ",request.form['MachineLearningDataset'])
            filename="MachineLearningDataset"
            #############################################

            reader = csv.reader(request.form['MachineLearningDataset'].splitlines())
            with open(filename, 'w', newline='') as csvfile:
                csv_writer = csv.writer(csvfile)
                csv_writer.writerows(reader)
            ############################################
            MachineLearningTrainer.buildModel(filename+'.csv')
            message = { 
                "Sucess" : 'Done'
            } 
            return jsonify(message)

    
    
    print("This is Get request")

    return render_template("machine_learning.html")



# # @app.route('/training_model', methods=['POST', 'GET']) #shows loading bar here, and success if model has been trained successfully
# # def training_model():
# #     if request.method == "POST":
# #         csv_file=request.form['csv_for_ML']
        
#         # print("CSV_FILE FOR MACHINE LEARNING IS:",csv_file)
#     return render_template("training_model.html")

@app.route('/prediction',methods=["GET","POST"])
def prediction():

    if request.method == "POST":
        pd.set_option('display.max_rows', None)
        received_data=request.form['csv_file_stored']
        print("Type of data received is ",type(received_data))
        print('Received data 2:', received_data)
        reader = csv.reader(received_data.splitlines())
        with open('TESTING.csv', 'w', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerows(reader)
        filename='TESTING.csv'
        dataFrame = pd.read_csv(filename)
        dataFrame.fillna(0, inplace=True)
        ML_Column = db['Machine_Learning_Model'] 
        Model_list=ML_Column.find()
        Machine_Learning_Model=""
        for model in Model_list:
            Machine_Learning_Model=model['Model']
        if 'referral' in dataFrame.columns:
            dataFrame.drop(['referral'], axis=1, inplace=True)
        Machine_Learning_Model=pickle.loads(Machine_Learning_Model)
        print(dataFrame)
        if 'encounterId' in dataFrame.columns:
            dataFrame.drop(['encounterId'], axis=1, inplace=True)
        labels=Machine_Learning_Model.predict(dataFrame)
        # print("LABELS",labels)
        # labels = pd.DataFrame(labels)
        # print("LABEL TYPE",type(labels))
        print("YAHIA")
        y=0
        print(labels)
        labels_dataframe = pd.DataFrame(labels,columns=['referral'])
        labels=list(labels)
        label_list=labels
        # labeled_dataset.to_csv('TESTING', index=False)
        mystring=""
        for element in labels:
            mystring=mystring+str(int(element))
        labels=mystring
        labeled_dataset=labels
        test_Data=pd.concat([dataFrame, labels_dataframe], axis=1)
        test_Data=test_Data.to_string()

        # print(test_Data)

        print("#############################################################################")
        print('Received data:', len(received_data.splitlines()))
        send_data=""
        len_oflist=len(label_list)
        counter=0
        label_list.insert(0,"Skip")
        print(len(label_list),len(received_data.splitlines()))
        for row , label_value in zip(received_data.splitlines(),label_list):
            if counter==0:
                send_data=send_data+row+'\\n'
                print("Special",send_data)
                counter+=1
                continue
            if float(label_value)==1.0:
                row=row[0:len(row)-1]+',1.0'
            else:
                row=row[0:len(row)-1]+',0.0'
            # print(row)
            
            send_data=send_data+row+'\\n'
        print("First row",received_data.splitlines()[0])
        print("Len now",len(label_list),len(received_data.splitlines()))
 
            
        return render_template("view.html",labeled_dataset=labeled_dataset,test_Data=test_Data,send_data=send_data,yes_update=1)


@app.route('/help')
def help():
    return render_template("help.html")

@app.route('/terms')
def terms():
    return render_template("terms.html")

@app.route('/main')
def main():
    return render_template("main.html")



@app.route('/accountmanagement/')
@login_required
@admin_required
def account_management():
        user_list=[]
        for x in collection.find():
            print("xxxxxxxxxxxxxxxxxxxx")
            print(x)
            if 'email' in x and x['email']!=Current_User.getEmail():
                user_list.append([x['userId'],x['username'],x['firstName'],x['lastName'],x['email'],x['role'],x['phone']])
        # username=request.form['Username']
        # print("Username value is ",username)
        return render_template("accountmanagement.html",user_list=user_list)


@app.route('/account_management_process', methods=['POST', 'GET'])
def account_management_process():
    if request.method == "POST":
        username=request.form['Roles']
        print("Role value is ",username)
        where_statement = {'userId': request.form['userid_hidden']}

# Specify the update operation
        update_statement = {"$set": {"username":request.form['Username'] ,"firstName":request.form['FirstName'],"lastName":request.form['LastName'],"email":request.form['Email'],"role":request.form['Roles'], "phone":request.form['Phone']}}

# Update a single document that matches the filter criteria
        result = collection.update_many(where_statement, update_statement)
        
        print("Matched:", result.matched_count)
        print("Modified:", result.modified_count)
    return redirect(url_for('account_management'))

@app.route('/account_management_delete', methods=['POST', 'GET'])
def account_management_delete():
    if request.method == "POST":
        # username=request.form['Roles']
        # print("Role value is ",username)
        where_statement = {'username': request.form['Hidden_Input']}
        collection.delete_one(where_statement)
    return redirect(url_for('account_management'))


@app.route('/sendmessage', methods=['POST', 'GET'])
def sendmessage():
    if request.method == "POST":
        message=request.form['message']
        firstname=request.form['first-name']
        lastname=request.form['last-name']
        email=request.form['email']

        email_sender_bot="annoyingchatbotspammerbr@gmail.com"
        email_sender_bot_pw="pxbl hxdx jmqe apwd"

        email_receiver="handyleaf11@gmail.com"

        subject_of_email=f"Message sent by {firstname} {lastname}"

        main_message="Yo can yo hear me"

        email_message = EmailMessage()

        email_message['From'] = email_sender_bot
        email_message['To'] = email_receiver
        email_message['Subject'] = subject_of_email

        email_message.set_content(message+'\nEmail address of sender is '+email)

        context = ssl.create_default_context()

        with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context) as smtp:
            smtp.login(email_sender_bot,email_sender_bot_pw)
            smtp.sendmail(email_sender_bot,email_receiver,email_message.as_string())
        return render_template("help.html")
    
@app.route('/register/', methods=['POST', 'GET'])
def register():
    error = ''
    print('Register start')
    try:
        if request.method == "POST":
            print('Received POST request')
            firstName = request.form['firstName']
            lastName = request.form['lastName']
            phone = request.form['phone']
            email = request.form['email']
            password = request.form['password']
            print('Form data received:', firstName, lastName, phone, email)

            if firstName and lastName and phone and email and password:
                print('All form fields filled')

                # Check if email already exists
                existing_user = collection.find_one({'email': email})
                if existing_user:
                    print('Email already taken, please choose another')
                    error = "Email already taken, please choose another"
                    return render_template("register.html", error=error)
                else:
                    # Generate a random username
                    username = firstName + str(random.randint(1, 999))
                    print('Generated username:', username)
                    existing_phone=collection.find_one({'email':email})
                    if existing_phone:
                        error_phone = "Phone already taken, please choose another"                     
                        return render_template("register.html", error_phone=error_phone)
                    # Insert new user into MongoDB
                    password_hash = sha256_crypt.hash(password)
                    counter_document = collection.find_one_and_update(
                        {"_id": "user_id"},
                        {"$inc": {"seq": 1}},
                        upsert=True,  # Add this option to insert a new document if not found
                        return_document=pymongo.ReturnDocument.AFTER
                    )
                    print("Counter document:", counter_document)  # Add this line for debugging

                    if counter_document is not None:
                        user_id = counter_document["seq"]
                    else:
                        # Handle the case when the counter document is None
                        # This could indicate an issue with initialization or query
                        print("Error: Counter document is None")
                    collection.insert_one({
                        'userId': user_id,
                        'username': username,
                        'firstName': firstName,
                        'lastName': lastName,
                        'phone': phone,
                        'email': email,
                        'password_hash': password_hash,
                        'role': 'Standard'  # Assign the default role
                    })
                    print("User registered successfully!")
                    session['logged_in'] = True
                    session['email'] = email
                    session['role'] = 'standard'
                    return render_template("logIn.html", message='User registered successfully and logged in..')
            else:
                print('Empty parameters')
                return render_template("register.html", error=error)
        else:
            print('GET request received')
            return render_template("register.html", error=error)
    except Exception as e:
        print('An error occurred during registration:', e)
        return render_template("register.html", error=str(e))
    return render_template("register.html", error=error)



# Code for the sign in page
@app.route('/logIn/', methods=["GET", "POST"])
def logIn():
    error = ''
    try:
        if request.method == "POST":
            print("log in Received POST request")
            email = request.form['email']
            password = request.form['password']
            user = collection.find_one({'email': email})

            if user:
                Current_User.setEmail(email)
                # UserList_Object.append(Current_User)
                print("User found in database")
                # Verify password
                if sha256_crypt.verify(password, user['password_hash']):
                    print("Password verified, logging in")
                    session['logged_in'] = True
                    session['email'] = email
                    session['role'] = user.get('role', 'standard')
                    print("You are now logged in")
                    return render_template('main.html', email=email, data='this is user specific data', role=session['role'])
                else:
                    error = "Invalid credentials email/password, try again."
                    print("Invalid password")
            else:
                error = "Email / password does not exist, login again"
                print("User not found in database")

        return render_template("logIn.html", error=error)
    except Exception as e:
        error = str(e) + " <br/> Invalid credentials, try again."
        return render_template("logIn.html", error=error)




@app.route("/logout/")
def logout():    
    session.clear()  # Clears session variables
    print("You have been logged out!")
    return render_template('logIn.html')

###############################################################
#sids code

@app.route('/account')
def account():
    if 'email' in session:
        email = session['email']
        # Retrieve data from MongoDB based on the user ID in the session
        data = collection.find_one({"email": email})
        if data:
            return render_template('account.html', data=data)
        else:
            return "User data not found"
    else:
        return "User session not found"





@app.route('/updateEmail/', methods=['POST'])
@login_required
def update_email():
    error = ''
    if request.method == 'POST':
        new_email = request.form['email']
        new_email_list=[new_email]
        print("New_email value is ",new_email)
        
        email = session.get('email')  # Assuming you have a user ID to identify the user
        if email:
            data = collection.find_one({"email": email})

            if new_email==data['email']:
                return render_template("account.html", data=data)
            test=collection.find_one({"email": new_email})
            if test is not None:
                return render_template("account.html", data=data ,message="Email has been already used")

            # Update the user's first name in MongoDB based on email
            if not validate_email(new_email_list[0]):
                pass
            else:
                collection.update_one(
                    {'_id': data["_id"]},
                    {'$set': {'email': new_email_list[0]}}
                )
                print("inside update_email ",data["_id"])
                print("New Email is",new_email_list[0])
                session['email']=new_email_list[0]
            email = session['email']
            # Retrieve data from MongoDB based on the user ID in the session
            data = collection.find_one({"email": email})
            if not validate_email(new_email_list[0]):
                print("Update_Email")
                return render_template("account.html", data=data ,message="Email does not follow format")

            return render_template("success.html", message="Your Email has been changed to '{}'".format(new_email))
        else:
            error = 'email not found'
    
    return render_template('account.html', error=error)





# @app.route('/updateEmail/', methods=['POST'])
# @login_required
# def update_email():
#     error = ''
#     if request.method == 'POST':
#         new_email = request.form['email']
        
#         email = session.get('email')  # Retrieve user's email from session
#         if email:
#             # Update the user's email in MongoDB
#             collection.update_one(
#                 {'email': email},
#                 {'$set': {'email': new_email}}
#             )
#             session['email'] = new_email  # Update email in session variable
#             return render_template("success.html", message="Your Email has been changed to '{}'".format(new_email))
#         else:
#             error = 'User email not found in session'
    
#     return render_template('account.html', error=error)


        

@app.route('/updateFirstName/', methods=['POST'])
@login_required
def update_first_name():
    error = ''
    if request.method == 'POST':
        new_first_name = request.form['firstName']
        
        email = session.get('email')  # Assuming you have a user ID to identify the user
        if email:
            # Update the user's first name in MongoDB based on email
            if not validate_firstname_and_lastname(new_first_name):
                pass
            else:
                collection.update_one(
                    {'email': email},
                    {'$set': {'firstName': new_first_name}}
                )
                email = session['email']
            # Retrieve data from MongoDB based on the user ID in the session
            data = collection.find_one({"email": email})
            if not validate_firstname_and_lastname(new_first_name):
                
                return render_template("account.html", data=data ,message="First name does not follow format")

            return render_template("success.html", message="Your First Name has been changed to '{}'".format(new_first_name))
        else:
            error = 'email not found'
    
    return render_template('account.html', error=error)




@app.route('/updateLastName/', methods=['POST'])
@login_required
def update_last_name():
    error = ''
    if request.method == 'POST':
        new_last_name = request.form['lastName']
        
        email = session.get('email')  # Assuming you have a user ID to identify the user
        if email:
            # Update the user's first name in MongoDB based on email
            if not validate_firstname_and_lastname(new_last_name):
                pass
            else:
                collection.update_one(
                    {'email': email},
                    {'$set': {'lastName': new_last_name}}
                )
                email = session['email']
            # Retrieve data from MongoDB based on the user ID in the session
            data = collection.find_one({"email": email})
            if not validate_firstname_and_lastname(new_last_name):
                
                return render_template("account.html", data=data ,message="Last name does not follow format")

            return render_template("success.html", message="Your First Name has been changed to '{}'".format(new_last_name))
        else:
            error = 'email not found'
    
    return render_template('account.html', error=error)





@app.route('/updatePhone/', methods=['POST'])
@login_required
def update_phone():
    error = ''
    if request.method == 'POST':
        new_phone = request.form['phone']
        
        email = session.get('email')  # Assuming you have a user ID to identify the user
        if email:
            data = collection.find_one({"email": email})

            if new_phone==data['phone']:
                return render_template("account.html", data=data)
            test=collection.find_one({"phone": new_phone})
            if test is not None:
                return render_template("account.html", data=data ,message="Phone number has been already used")

            # Update the user's first name in MongoDB based on email
            if not validate_phone(new_phone):
                pass
            else:
                print("Inside updatephone email is",email)
                collection.update_one(
                    {'email': email},
                    {'$set': {'phone': new_phone}}
                )
            email = session['email']
            # Retrieve data from MongoDB based on the user ID in the session
            data = collection.find_one({"email": email})
            if not validate_phone(new_phone):
                return render_template("account.html", data=data ,message="Phone number does not follow format")

            return render_template("account.html", data=data)
        else:
            error = 'email not found'
    
    return render_template('account.html', error=error)




import hashlib



@app.route('/updatePassword/', methods=['POST'])
@login_required
def update_password():
    error = ''
    if request.method == 'POST':
        new_password = request.form['password']
        
        email = session.get('email')  # Assuming you have a user ID to identify the user
        if email:
            # Update the user's first name in MongoDB based on email
            if not validate_password(new_password):
                pass
            else:
                collection.update_one(
                    {'email': email},
                    {'$set': {'password_hash': sha256_crypt.hash(new_password)}}
                )
            email = session['email']
            # Retrieve data from MongoDB based on the user ID in the session
            data = collection.find_one({"email": email})
            if not validate_password(new_password):
                
                return render_template("account.html", data=data ,message="password does not follow format")

            return render_template("success.html", message="Your Password has been updated successfully to '{}'".format(new_password))
        else:
            error = 'email not found'
    
    return render_template('account.html', error=error)


if __name__ == '__main__':
    app.run(port=5003, debug=True)
