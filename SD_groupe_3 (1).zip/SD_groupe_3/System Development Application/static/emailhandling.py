from email.message import EmailMessage
import smtplib
import ssl

email_sender_bot="annoyingchatbotspammerbr@gmail.com"
email_sender_bot_pw="pxbl hxdx jmqe apwd"

email_receiver="handyleaf11@gmail.com"

subject_of_email="Hello World!"

main_message="Yo can yo hear me"

email_message = EmailMessage()

email_message['From'] = email_sender_bot
email_message['To'] = email_receiver
email_message['Subject'] = subject_of_email

email_message.set_content(main_message)

context = ssl.create_default_context()

with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context) as smtp:
	smtp.login(email_sender_bot,email_sender_bot_pw)
	smtp.sendmail(email_sender_bot,email_receiver,email_message.as_string())