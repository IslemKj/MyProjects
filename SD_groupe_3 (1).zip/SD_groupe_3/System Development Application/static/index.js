
let menuicn = document.querySelector(".menuicon"); 
let nav = document.querySelector(".navcontainer"); 

menuicn.addEventListener("click", () => { 
	nav.classList.toggle("navclose"); 
})




csvData = localStorage.getItem('uploadedCSV');

const referralData = processReferralData(csvData);
const pipData = processPIP(csvData);
const bmiData = processBMI(csvData);



// Check if csvData is available
if (csvData) {
    
    const pieChartCanvas = document.getElementById('pieChartCanvas');
    renderPieChart(referralData, pieChartCanvas);
    

   
    const pipPieChartCanvas = document.getElementById('pipPieChartCanvas');
    renderPIPChart(pipData, pipPieChartCanvas);

    // Generate BMI data and charts
    
    const bmiPieChartCanvas = document.getElementById('bmiPieChartCanvas');
    renderBMIChart(bmiData, bmiPieChartCanvas);

    calculateStatistics(csvData);
    //populatePatientList(csvData);

    // Generate PDF with charts and tables
    //generateTable(referralData, pipData, bmiData);
} else {
    console.error('No CSV data found in localStorage.');
}


function processReferralData(csvData) {
    const rows = csvData.split('\n').slice(1); // Exclude header row
    const referralData = { Referred: 0, 'Not Referred': 0, Unknown: 0 }; // Initialize referral data object

    rows.forEach(row => {
        const referral = row.split(',')[row.split(',').length - 1].trim(); // Get referral status from last column
        if (referral === '1.0' || referral === '1.000') {
            referralData['Referred']++;
        } else if (referral === '0.0' || referral === '0.000') {
            referralData['Not Referred']++;
        } else {
            referralData['Unknown']++;
        }
    });

    return referralData;
}

function renderPieChart(referralData, canvas) {
    const ctx = canvas.getContext('2d');
    const pieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(referralData),
            datasets: [{
                data: Object.values(referralData),
                backgroundColor: ['#b91d47', '#00aba9', '#2b5797']
            }]
        },
        options: {
            title: {
                display: true,
                text: 'Patient Referral Status'
            }
        }
    });
}

function processPIP(csvData) {
    const rows = csvData.split('\n').slice(1); // Exclude header row
    const pipData = { 'Low PIP': 0, 'Normal PIP': 0, 'High PIP': 0 }; // Initialize PIP data object

    rows.forEach(row => {
        const pipValue = parseFloat(row.split(',')[9]); // Get PIP value from the appropriate column

        if (!isNaN(pipValue) && pipValue > 0) {
            if (pipValue < 20) {
                pipData['Low PIP']++;
            } else if (pipValue <= 30) {
                pipData['Normal PIP']++;
            } else {
                pipData['High PIP']++;
            }
        }
    });

    return pipData;
}

function renderPIPChart(pipData, canvas) {
    const ctx = canvas.getContext('2d');
    const pipPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(pipData),
            datasets: [{
                data: Object.values(pipData),
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56']
            }]
        },
        options: {
            title: {
                display: true,
                text: 'PIP Distribution'
            }
        }
    });
}

function processBMI(csvData) {
    const rows = csvData.split('\n').slice(1); // Exclude header row
    const bmiData = { 'Underweight': 0, 'Normal': 0, 'Overweight': 0, 'Obese': 0 }; // Initialize PIP data object

    rows.forEach(row => {
        const bmiValue = parseFloat(row.split(',')[16]); // Get PIP value from the appropriate column

        if (!isNaN(bmiValue) && bmiValue > 0) {
            if (bmiValue < 25.5) {
                bmiData['Underweight']++;
            } else if (bmiValue <= 35.5 ) {
                bmiData['Normal']++;
            } else if (bmiValue <= 45.5) {
                bmiData['Overweight']++;
            } else {
                bmiData['Obese']++;
            }
        }
    });

    return bmiData;
}

function renderBMIChart(bmiData, canvas) {
    const ctx = canvas.getContext('2d');
    const bmiPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(bmiData),
            datasets: [{
                data: Object.values(bmiData),
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56','#2b5797']
            }]
        },
        options: {
            title: {
                display: true,
                text: 'BMI Distribution'
            }
        }
    });
}

function generateTableData(data) {
    const tableData = [];
    Object.entries(data).forEach(([category, count]) => {
        tableData.push([category, count]);
    });
    return tableData;
}

document.getElementById('generateTableBtn').addEventListener('click', function() {
    generateTable(referralData, pipData, bmiData);
});


//const combinedData = generateTableData(bmiData, referralData, pipData);


function generateTable(referralData, pipData, bmiData) { 
    console.log("Referral Data:", referralData);
    console.log("PIP Data:", pipData);
    console.log("BMI Data:", bmiData);
    
    // Check if bmiData is defined
    if (typeof bmiData !== 'undefined') {
        // Convert data to table format
        const referralDataTable = generateTableData(referralData);
        const pipDataTable = generateTableData(pipData);
        const bmiDataTable = generateTableData(bmiData);

        // Generate PDF with embedded tables 
        const pdf = new jsPDF(); 
        const startY = 20; // Initial starting position of table

        // Add referral data table
        pdf.autoTable({ 
            startY: startY,
            head: [['Referral Category', 'Number']], 
            body: referralDataTable 
        });  

        // Add PIP data table
        pdf.autoTable({ 
            startY: startY + 100, // Adjust startY for spacing
            head: [['PIP Category', 'Number']], 
            body: pipDataTable 
        }); 

        // Add BMI data table
        pdf.autoTable({ 
            startY: startY + 200, // Adjust startY for spacing
            head: [['BMI Category', 'Number']], 
            body: bmiDataTable 
        }); 

        // Save PDF
        pdf.save('Table.pdf');
    } else {
        console.error('bmiData is not defined or is undefined.');
    }
}

function generateChart(referralData, pipData, bmiData) { 

    // Convert canvas elements to images 
    const pieChartCanvas = document.getElementById('pieChartCanvas'); 
    const pipPieChartCanvas = document.getElementById('pipPieChartCanvas'); 
    const bmiPieChartCanvas = document.getElementById('bmiPieChartCanvas'); 


    const pieChartImage = pieChartCanvas.toDataURL(); 
    const pipPieChartImage = pipPieChartCanvas.toDataURL(); 
    const bmiPieChartImage = bmiPieChartCanvas.toDataURL(); 


    // Generate PDF with embedded images and tables 
    const pdf = new jsPDF(); 
    const width = 100; // Width of each chart image 
    const height = 100; // Height of each chart image 
    const spacing = 10; // Spacing between charts 
    const tableWidth = 80; // Width of each table 
    const tableHeight = 30; // Height of each table 

    // Add pie chart image and table on page 1 
    pdf.addImage(pieChartImage, 'PNG', 10, 20, width, height); 
    pdf.addPage(); 

    // Add pip pie chart image and table on page 2 
    pdf.addImage(pipPieChartImage, 'PNG', 10, 20, width, height); 
    pdf.addPage(); 

    // Add bmi pie chart image and table on page 3 
    pdf.addImage(bmiPieChartImage, 'PNG', 10, 20, width, height); 
    pdf.save('charts.pdf'); 
}

function generatePDF(referralData, pipData, bmiData) {
    const pieChartCanvas = document.getElementById('pieChartCanvas'); 
    const pipPieChartCanvas = document.getElementById('pipPieChartCanvas'); 
    const bmiPieChartCanvas = document.getElementById('bmiPieChartCanvas'); 

    const pieChartImage = pieChartCanvas.toDataURL(); 
    const pipPieChartImage = pipPieChartCanvas.toDataURL(); 
    const bmiPieChartImage = bmiPieChartCanvas.toDataURL(); 

    const referralDataTable = generateTableData(referralData);
    const pipDataTable = generateTableData(pipData);
    const bmiDataTable = generateTableData(bmiData);

    // Generate PDF with embedded charts and tables 
    const pdf = new jsPDF(); 
    const width = 100; // Width of each chart image 
    const height = 100; // Height of each chart image 
    const spacing = 10; // Spacing between charts and tables
    const tableWidth = 80; // Width of each table 
    const tableHeight = 30; // Height of each table 
    const startY = 20; // Initial starting position

    // Add pie chart and referral data table on page 1
    pdf.addImage(pieChartImage, 'PNG', 10, 20, width, height); 
    pdf.autoTable({ 
        startY: startY + height + spacing,
        head: [['Referral Category', 'Number']], 
        body: referralDataTable,
        theme: 'striped', // Apply a striped theme to the table
        styles: { halign: 'center' } // Center-align table content
    });  

    // Add pip pie chart and PIP data table on page 2
    pdf.addPage();
    pdf.addImage(pipPieChartImage, 'PNG', 10, 20, width, height); 
    pdf.autoTable({ 
        startY: startY + height + spacing,
        head: [['PIP Category', 'Number']], 
        body: pipDataTable,
        theme: 'striped',
        styles: { halign: 'center' }
    }); 

    // Add bmi pie chart and BMI data table on page 3
    pdf.addPage(); 
    pdf.addImage(bmiPieChartImage, 'PNG', 10, 20, width, height); 
    pdf.autoTable({ 
        startY: startY + height + spacing,
        head: [['BMI Category', 'Number']], 
        body: bmiDataTable,
        theme: 'striped',
        styles: { halign: 'center' }
    }); 

    // Save PDF
    pdf.save('combination.pdf'); 
}

        

document.getElementById('generatePDF').addEventListener('click', function() {
    generatePDF(referralData, pipData, bmiData);
});

function calculateStatistics(csvData) {
    let numberOfPatients = 0;
    let referredPatients = 0;
    let notReferredPatients = 0;

    const rows = csvData.split('\n');
    // Start iterating from index 1 to exclude the header row
    for (let i = 1; i < rows.length; i++) {
        const columns = rows[i].split(',');
        if (columns.length >= 4) { // Ensure there are enough columns
            numberOfPatients++;
            const referral = columns[columns.length - 1].trim();
            if (referral === '1.0') {
                referredPatients++;
            } else if (referral === '0.0') {
                notReferredPatients++;
            }
        }
    }

    document.getElementById('numberOfPatients').textContent = numberOfPatients;
    document.getElementById('referredPatients').textContent = referredPatients;
    document.getElementById('notReferred').textContent = notReferredPatients;
}