import regex


def validate_username(email):
    if not regex.match('^[A-Za-z0-9]{3,14}$',email):
                return False
    return True

def validate_firstname_and_lastname(name):
    if not regex.match('^[A-Z][a-z]{2,14}$',name):
                return False
    return True

def validate_phone(phone):
    if not regex.match('^[0-9]{12}$',phone):
                return False
    return True

def validate_email(email):
    if not regex.match('^[A-Za-z0-9\_\-]{4,15}@(gmail|yahoo|outlook)\.com$',email):
                return False
    return True

def validate_password(password):
        if not regex.match('^.{10,20}$',password):
                return False
        return True
