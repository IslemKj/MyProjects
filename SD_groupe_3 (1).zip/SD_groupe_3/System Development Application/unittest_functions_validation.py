import unittest
from index import app
import time

from MachineLearningTrainer import buildModel

class TestFlaskApp(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
   
        
    def test_index_route(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Register</h1>", response.data)  # Check for a string that uniquely identifies the content

    def test_about_route(self):
        response = self.app.get('/about')
        self.assertEqual(response.status_code, 200)

    def test_analyse_route(self):
        response = self.app.get('/analyse')
        self.assertEqual(response.status_code, 200)

    def test_view_route(self):
        response = self.app.get('/view')
        self.assertEqual(response.status_code, 200)

    def test_upload_route(self):
        response = self.app.get('/upload')
        self.assertEqual(response.status_code, 200)

    #def test_machine_learning_route(self):
        #response = self.app.post('/machine_learning', data={'MachineLearningDataset': 'test_data'})
        #self.assertEqual(response.status_code, 200)
        #self.assertEqual(response.json, {"Sucess": "Done"})

    #def test_prediction_route(self):
        #response = self.app.post('/prediction', data={'csv_file_stored': 'test_data'})
        #self.assertEqual(response.status_code, 200)

    def test_help_route(self):
        response = self.app.get('/help')
        self.assertEqual(response.status_code, 200)

    def test_terms_route(self):
        response = self.app.get('/terms')
        self.assertEqual(response.status_code, 200)

    def test_main_route(self):
        response = self.app.get('/main')
        self.assertEqual(response.status_code, 200)

    def test_accountmanagement_route(self):
        response = self.app.get('/accountmanagement/')
        self.assertEqual(response.status_code, 200)

    #def test_account_management_process_route(self):
        #response = self.app.post('/account_management_process', data={'userid_hidden': 'test_user_id'})
       # self.assertEqual(response.status_code, 302)

    def test_account_management_delete_route(self):
        response = self.app.post('/account_management_delete', data={'Hidden_Input': 'test_input'})
        self.assertEqual(response.status_code, 302)

    #def test_sendmessage_route(self):
        #response = self.app.post('/sendmessage', data={'message': 'test_message', 'first-name': 'test', 'last-name': 'user', 'email': 'test@example.com'})
        #self.assertEqual(response.status_code, 200)

    def test_register_route(self):
        response = self.app.post('/register/', data={'firstName': 'test', 'lastName': 'user', 'phone': '1234567890', 'email': 'test@example.com', 'password': 'test_password'})
        self.assertEqual(response.status_code, 200)

    def test_login_route(self):
        response = self.app.post('/logIn/', data={'email': 'test@example.com', 'password': 'test_password'})
        self.assertEqual(response.status_code, 200)

    def test_logout_route(self):
        response = self.app.get('/logout/')
        self.assertEqual(response.status_code, 200)
        
         
    #Testing for the machine learning and the time taken to train the model    
    def test_machine_learning_route(self):
        start_time = time.time()
        response = self.app.post('/machine_learning', data={'MachineLearningDataset': 'test_data'})
        end_time = time.time()
        elapsed_time = end_time - start_time

        self.assertEqual(response.status_code, 200)
        #self.assertEqual(response.json, {"Sucess": "Done"})
        self.assertLessEqual(elapsed_time, 300)  # Check if the time taken is less than or equal to 300 seconds (5 minutes)
    

if __name__ == '__main__':
    unittest.main()


