READ ME FILE:

For analysising unlabelled data make sure
1-go to Analysis Page, Upload file named Feeding_Dashboard_data__For_Prediction 
2-then please wait until it finishes executing, do not go to other pages until it finishes



ADMIN DETAILS
EMAIL:side@gmail.com
PW:1234

For training MACHINE LEARNING MODEL

1-only for admins click on brain icon on top if you are an admin
2-upload file named MachineLearningDataset
2-then please wait until it finishes executing, do not go to other pages until it finishes
if it finishes you will see word "DONE" displayed on the screen